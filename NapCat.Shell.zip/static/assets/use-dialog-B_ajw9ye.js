import{R as o}from"./react-router-dom-BuK5Vxqh.js";import{bA as t}from"./index-CccuTvbI.js";const s=()=>o.useContext(t);export{s as u};
